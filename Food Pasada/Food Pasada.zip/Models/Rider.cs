﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Food_Pasada.Models
{
    public class Rider
    {
        public string rider_name;
    }
}